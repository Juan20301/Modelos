public class SalidaPantalla extends Salida {

    @Override
    public void enviar(String contenido) {
        System.out.println(contenido);
    }
}
