public abstract class Salida {
    public abstract void enviar(String contenido);

}
