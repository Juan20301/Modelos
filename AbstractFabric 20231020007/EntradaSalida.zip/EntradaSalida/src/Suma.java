public class Suma extends Operacion {

    @Override
    public float operar(float a, float b) {
        return a + b;
    }
    
}
