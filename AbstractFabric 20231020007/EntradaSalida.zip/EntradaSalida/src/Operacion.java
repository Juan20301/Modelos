public abstract class Operacion {

public abstract float operar(float a, float b);

}
