public abstract class Entrada {
    public abstract String recibir();
}
