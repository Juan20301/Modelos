public abstract class FabricaAbstracta {
    public abstract Entrada getEntrada();
    public abstract Salida getSalida();

}
